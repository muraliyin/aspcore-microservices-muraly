using System;
using System.Collections.Generic;
namespace cms.Models {

    public class PlantInput {
        public Guid PlantId { get; set; }

    }
}