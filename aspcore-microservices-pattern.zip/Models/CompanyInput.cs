using System;
using System.Collections.Generic;
namespace cms.Models
{

    public class CompanyInput
    {
        public Guid CompanyId { get; set; }

    }
}